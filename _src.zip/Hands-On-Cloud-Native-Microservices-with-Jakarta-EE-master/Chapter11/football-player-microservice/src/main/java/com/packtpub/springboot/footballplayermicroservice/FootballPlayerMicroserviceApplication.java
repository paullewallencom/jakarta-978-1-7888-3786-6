package com.packtpub.springboot.footballplayermicroservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FootballPlayerMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(FootballPlayerMicroserviceApplication.class, args);
	}
}
