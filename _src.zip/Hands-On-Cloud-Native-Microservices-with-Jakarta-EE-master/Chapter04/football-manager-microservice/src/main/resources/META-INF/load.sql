INSERT INTO FOOTBALL_MANAGER (name, surname, age, nickname) VALUES ('Mauro', 'Vocale', 38, 'Mauryno7');
INSERT INTO FOOTBALL_MANAGER (name, surname, age, nickname) VALUES ('Luigi', 'Fugaro', 45, 'Foogaro');
INSERT INTO FOOTBALL_MANAGER (name, surname, age, nickname) VALUES ('Java', 'Bean', 25, 'JB_Enterprise');
INSERT INTO FOOTBALL_MANAGER (name, surname, age, nickname) VALUES ('Jose', 'Mourinho', 55, 'Special_One');
INSERT INTO FOOTBALL_MANAGER (name, surname, age, nickname) VALUES ('Carlo', 'Ancellotti', 55, 'King_Carlo');