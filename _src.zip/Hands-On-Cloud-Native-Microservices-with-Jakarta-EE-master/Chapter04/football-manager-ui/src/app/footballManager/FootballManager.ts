export class FootballManager {

  id: number;
  name: string;
  surname: string;
  age: number;
  nickname: string;

  constructor(id: number, name: string, surname: string, age: number, nickname: string){
    this.id = id;
    this.name = name;
    this.surname = surname;
    this.age = age;
    this.nickname = nickname;
  }

}
